# # matrix1 = [[1, 2, 3], 
# #            [4, 5, 6], 
# #            [7, 8, 9]] 

# # matrix2 = [[9, 8, 7], 
# #            [6, 5, 4], 
# #            [3, 2, 1]] 

# # result = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

# # for i in range(len(matrix1)): 
# #          for j in range(len(matrix1[0])): 
# #                   for k in range(len(matrix2)): 
# #                         result[i][j] += matrix1[i][k] * matrix2[k][j]

# # print(result)

print("Введите данные первой матрицы:")
A = []
while True: 
    line = input("Введите строку матрицы (или пустую строку для завершения): ")
    if line == "":
        break
    A.append(list(map(int, line.split())))
    print(A)

print("Введите данные Второй матрицы:")
B = []
while True: 
    line = input("Введите строку матрицы (или пустую строку для завершения): ")
    if line == "":
        break
    B.append(list(map(int, line.split())))
    print(B)

rows_A, cols_A = len(A), len(A[0])
rows_B, cols_B = len(B), len(B[0])

if cols_A != rows_B:
    raise ValueError("Количество столбцов первой матрицы должно быть равно количеству строк второй матрицы.")

C = [[0] * cols_B for _ in range(rows_A)]

for i in range(rows_A):
    for j in range(cols_B):
        for k in range(cols_A):
            C[i][j] += A[i][k] * B[k][j]


print("Результат умножения матриц:")
for row in C:
        print(' '.join(map(str, row)))