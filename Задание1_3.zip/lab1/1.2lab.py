import requests

# Введите имя пользователя и репозиторий
print('Введите имя пользователя:')
username = input()  # 'Nastya1337'
print('Введите имя репозитория:')
repository = input()  # 'lab1'

# URL API GitHub для получения коммитов
url = f'https://api.github.com/repos/{username}/{repository}/commits'

# Отправляем GET-запрос к API
response = requests.get(url)

# Проверяем статус ответа
if response.status_code == 200:
    commits = response.json()
    
    # Словарь для подсчета коммитов по электронным адресам
    email_commit_count = {}

    # Перебираем все коммиты
    for commit in commits:
        author_email = commit['commit']['author']['email']
        
        # Увеличиваем счетчик коммитов для данного email
        if author_email in email_commit_count:
            email_commit_count[author_email] += 1
        else:
            email_commit_count[author_email] = 1

    # Формируем список для хранения результата
    result = []
    
    # Заполняем результат пособом перебора значений в словаре
    for email, count in email_commit_count.items():
        result.append((email, count))

    # Выводим результат в порядке убывания количества коммитов, без использования sort()
    max_commits = max(count for _, count in result) if result else 0
    while max_commits > 0:
        for email, count in result:
            if count == max_commits:
                print(f'Email: {email}, Количество коммитов: {count}')
        max_commits -= 1

else:
    print(f'Не удалось получить данные: {response.status_code} - {response.text}')